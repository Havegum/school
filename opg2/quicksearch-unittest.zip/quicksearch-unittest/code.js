function checkSingleQuery(q, marker) {
  return false;
}
